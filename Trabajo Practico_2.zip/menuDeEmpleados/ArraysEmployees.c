#include "ArraysEmployees.h"
#include <stdio.h>
#include <string.h>
#include "caidevValidate.h"
#include "ArraysEmployees.h"
/*
struct
{
 int id;
 char name[51];
 char lastName[51];
 float salary;
 int sector;
 int isEmpty;
}typedef Employee;
*/
/*
void mostrarEmpleado(Employee empleado);
int existeEmpleado(Employee* list, int len);
int initEmployees(Employee* list, int len);
int addEmployee(Employee* list, int len, int id, char name[],char lastName[],float salary,int sector);
int findEmployeeById(Employee* list, int len,int id);
int removeEmployee(Employee* list, int len, int id);
int sortEmployees(Employee* list, int len, int order);
int printEmployees(Employee* list, int length);
void mostrarInformeSalario(Employee* list, int length);

*/
// estructura del tipo Empleado
/*struct
{
 int id;
 char name[51];
 char lastName[51];
 float salary;
 int sector;
 int isEmpty;
}typedef Employee;
*/
// me muestra los datos de UN empleado
void mostrarEmpleado(Employee empleado){

//	printf("---------------------------------------------------------------------------------------------------------\n");
//	printf("| ID |                NOMBRE |                APELLIDO |              SALARIO    |   SECTOR    |  ALTA  |\n");
//	printf("---------------------------------------------------------------------------------------------------------\n");
	printf("|%4d|     %17s |         %15s |            %9.2f    |    %3d      |   %d    |\n",empleado.id,empleado.name,empleado.lastName,empleado.salary,empleado.sector,empleado.isEmpty);
	printf("---------------------------------------------------------------------------------------------------------\n");

}
// con esta funcion verifico que al menos halla un SOLO empleado
int existeEmpleado(Employee* list, int len){
	int i;
    int cantEmpleadosCargados = 0;
	for(i = 0;i < len;i++){
		if((list[i].isEmpty == 0)){
			cantEmpleadosCargados++;
		}
	}
	if(cantEmpleadosCargados==0){
		return 0;
	}else{
		return 1;
	}
}
// En esta funcion, cambio el valor de disponibilidad(isEmpty(vacia) de los empleados a TRUE (osea 1)
int initEmployees(Employee* list, int len)
{

		int i;
		for(i = 0;i < len;i++){

			list[i].isEmpty = 1;

		}

 return 0;
}

// En esta funcion agrego a un empleado , en la primer posicion libre que encuentre, es decir cuyo valor isEmpty = 1
int addEmployee(Employee* list, int len, int id, char name[],char lastName[],float salary,int sector){
	int i = 0;
	// aca voy avanzando hasta encontrar la primer posicion libre en el vector
	while(list[i].isEmpty != 1){
		i++;
	}
	// como i es la primer posicion que esta disponible, guardo los datos del empleados que quiero ingresar
	if(i<len){

		list[i].id = id;
		strcpy(list[i].name,name);
		strcpy(list[i].lastName,lastName);
		list[i].salary = salary;
		list[i].sector = sector;
		list[i].isEmpty = 0;

		return 0;
	}else{
		printf("EL EMPLEADO NO PUDO SER A�ADIDO, PORQUE YA NO HAY ESPACIO\n");
		return -1;
	}

}

// Busca un empleado recibiendo como par�metro de b�squeda su Id.
int findEmployeeById(Employee* list, int len,int id)
{
 int i = 0;
 //voy recorriendo el vector mientras el vector no llegue al final ni la id no coincida con la que busco
 	while((i < len ) && (list[i]).id != id){
 		i++;
 	}
    if(i<len){
    	return 1;
    }else{
 		return -1;
 }
}

int removeEmployee(Employee* list, int len, int id)
{
 int i = 0;
 //voy recorriendo el vector mientras el vector no llegue al final ni la id no coincida con la que busco
 	while((i < len ) && (list[i]).id != id){
 		i++;
 	}

	if(i<len){
 		list[i].isEmpty = 1;
 		return 0;
 	}else{
	 	return -1;
 	}

}

int sortEmployees(Employee* list, int len, int order)
{
 // order = 0 decreciente
 // order = 1 creciente
 // creo una variable auxiliar de tipo Empleado
 Employee auxEmpleado;
 int i;
 if(order == 1){
 // ordena por apellido de empleado y sector de forma creciente
	 for(i = 0;i < len - 1 ;i++){
	 	int j;
	 	for(j = i;j < len - 1 ;j++){

			 if(strcmp(list[i].lastName,list[j+1].lastName)==1){


				auxEmpleado = list[i];
				list[i] = list[j+1];
				list[j+1] = auxEmpleado;

			}else{
				if((strcmp(list[i].lastName,list[j+1].lastName)==0) && (list[i].sector > list[j+1].sector)){

					auxEmpleado = list[i];
					list[i] = list[j+1];
					list[j+1] = auxEmpleado;

			}

			}
		 }

	 }
 }else{if(order == 0){
    // ordena por apellido de empleado y sector de forma decreciente

	 for(i = 0;i < len - 1 ;i++){
	 	int j;
	 	for(j = i;j < len - 1 ;j++){

			 if(strcmp(list[i].lastName,list[j+1].lastName)==-1){


				auxEmpleado = list[i];
				list[i] = list[j+1];
				list[j+1] = auxEmpleado;

			}else{
				if((strcmp(list[i].lastName,list[j+1].lastName)==0) && (list[i].sector < list[j+1].sector)){

					auxEmpleado = list[i];
					list[i] = list[j+1];
					list[j+1] = auxEmpleado;

			}

			}
		 }

	 }

 }
}



 return 0;
}

// me muestra por pantalla a los empleados
int printEmployees(Employee* list, int length)
{
	int i;
//	printf("  ID                  NOMBRE                  APELLIDO                SALARIO        SECTOR       ALTA \n");
 	printf("---------------------------------------------------------------------------------------------------------\n");
	printf("| ID |                NOMBRE |                APELLIDO |              SALARIO    |   SECTOR    |  ALTA  |\n");
	printf("---------------------------------------------------------------------------------------------------------\n");

	 for(i = 0;i < length;i++){
			// solo muestros aquellos empleados que esten cargados
			if(list[i].isEmpty == 0){
			//  usa la funcion mostrarEmpleado
				mostrarEmpleado(list[i]);

			}

 	}

 return 0;
}
//Muestra total y promedio de los salarios, y cu�ntos empleados superan el salario promedio.
void mostrarInformeSalario(Employee* list, int length){

	int cantidadEmpleadosAlta = 0;
	int cantEmplSueldoM = 0;
	float totalSalario = 0;
	float promedioSueldo = 0;
	int i ;
	//calculo la cantidad total sueldo solo de los empleados cargados
	for(i = 0;i < length;i++){
		if(list[i].isEmpty==0){
			cantidadEmpleadosAlta++;
			totalSalario = list[i].salary + totalSalario;
		}
	}
	//calculo el promedio
	promedioSueldo = totalSalario/cantidadEmpleadosAlta;
	//calculo la cantidad de empleados con un sueldo mayor al promedio
	for(i = 0;i < length;i++){
		if((list[i].isEmpty==0)&&(list[i].salary > promedioSueldo)){
			cantEmplSueldoM++;
		}
	}
	printf("------------------------------------INFORME--------------------------------------\n");
	printf("| LA SUMA TOTAL DE LOS SALARIOS ES : %8.2f                                   |\n",totalSalario);
	printf("| EL PROMEDIO DEL TOTAL DE LOS SALARIOS ES : %8.2f                            |\n",promedioSueldo);
	printf("| LA CANTIDAD DE EMPLEADOS, CUYO SUELDO SUPERA EL PROMEDIO ES : %4d             |\n",cantEmplSueldoM);
	printf("---------------------------------------------------------------------------------\n\n\n\n");

}
