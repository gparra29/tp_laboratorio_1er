#include <stdio.h>
#include <string.h>
#include "ArraysEmployees.h"

#include <stdlib.h>
#include "menu.h"

int main(){

	menu();
    /*Employee empleados[5];

//	int i = strcmp("Lopez","Perez");
//	printf("%d",i);

	//Employee empleado;
	//empleado.id = 10;

    empleados[0].id = 1;
	strcpy(empleados[0].name,"Carlos");
	strcpy(empleados[0].lastName,"Perez");
	empleados[0].salary = 100000.0;
	empleados[0].sector = 54;
	empleados[0].isEmpty = 0;


	empleados[1].id = 2;
	strcpy(empleados[1].name,"Marcelo Tomas");
	strcpy(empleados[1].lastName,"Lopez");
	empleados[1].salary = 10551.0;
	empleados[1].sector = 58;
	empleados[1].isEmpty = 0;

	empleados[2].id = 3;
	strcpy(empleados[2].name,"Daniela Ana Maria");
	strcpy(empleados[2].lastName,"Perez");
	empleados[2].salary = 50001.0;
	empleados[2].sector = 53;
	empleados[2].isEmpty = 1;

	empleados[3].id = 4;
	strcpy(empleados[3].name,"Jorge");
	strcpy(empleados[3].lastName,"Diaz");
	empleados[3].salary = 51000.0;
	empleados[3].sector = 57;
	empleados[3].isEmpty = 0;

	empleados[4].id = 5;
	strcpy(empleados[4].name,"Lolo");
	strcpy(empleados[4].lastName,"Perez");
	empleados[4].salary = 514.0;
	empleados[4].sector = 59;
	empleados[4].isEmpty = 0;

    printEmployees(empleados,5);
    //int removeConfirmacion = removeEmployee(empleados,5,3);
	printEmployees(empleados,5);
    int valor = addEmployee(empleados,5,3,"Gohan","Son",450,12);
    printf("%d",valor);
    printEmployees(empleados,5);

	informar(empleados,5);
//	mostrarInformeSalario(empleados,5);
	//funciona
	//int numero = addEmployee(empleados,4,1,"Marcelo Tomas Ana","Toledo juan",4251.0,15);
	//sortEmployees(empleados,5,0);
	//printEmployees(empleados,5);
	//int idEmpleado = findEmployeeById(empleados,5,4);
    //mostrarEmpleado(empleados[idEmpleado]);
//  int removeConfirmacion = removeEmployee(empleados,5,3);

//   printEmployees(empleados,5);

*/
return 0;
}


