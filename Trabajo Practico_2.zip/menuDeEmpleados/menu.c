#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "menu.h"
#include "ArraysEmployees.h"
#include "caidevValidate.h"

void menu(){
	/*
	1. ALTAS: Se debe permitir ingresar un empleado calculando autom�ticamente el n�mero
	de Id. El resto de los campos se le pedir� al usuario.
	2. MODIFICAR: Se ingresar� el N�mero de Id, permitiendo modificar: o Nombre o Apellido
	o Salario o Sector
	3. BAJA: Se ingresar� el N�mero de Id y se eliminar� el empleado del sistema.
	4. INFORMAR:
		1. Listado de los empleados ordenados alfab�ticamente por Apellido y Sector.
		2. Total y promedio de los salarios, y cu�ntos empleados superan el salario promedio.
	*/
	Employee empleados[1000] = {};
	//inicializo los empleados
	int iniciarVectores = initEmployees(empleados,1000);
	int opcion;
	do{

	printf("\n\n\n************************MENU************************\n");
	printf("* (1)DAR ALTA A UN EMPLEADO                        *\n");
	printf("* (2)MODIFICAR DATOS DE UN EMPLEADO                *\n");
	printf("* (3)DAR BAJA A UN EMPLEADO                        *\n");
	printf("* (4)INFORMAR                                      *\n");
	printf("* (5)SALIR                                         *\n");
	printf("****************************************************\n");
	//system("cls");  ME LIMPIA LA PANTALLA
	printf("INGRESE UNA OPCION : ");

	scanf("%d",&opcion);

		switch(opcion){

			case 1:

				ingresarEmpleado(empleados,1000);
				break;
			case 2:

				modificarEmpleado(empleados,1000);
				break;
			case 3:

				darBajaEmpleado(empleados,1000);
				break;
			case 4:

				informar(empleados,1000);
				break;
		}

	}while(opcion != 5);

}

void ingresarEmpleado(Employee* list, int length){
	int id;
 	char name[51];
 	char lastName[51];
 	float salary;
    int sector;


		printf("\nINGRESE NUMERO ID DEL EMPLEADO : ");
		scanf("%d",&id);


		printf("\nINGRESE NOMBRE DEL EMPLEADO : ");
		scanf("%s",&name);


		printf("\nINGRESE APELLIDO DEL EMPLEADO : ");
		scanf("%s",lastName);


		printf("\nINGRESE SUELDO DEL EMPLEADO : ");
		scanf("%f",&salary);


		printf("\nINGRESE NUMERO DEL SECTOR DEL EMPLEADO : ");
		scanf("%d",&sector);

    //verifica si el empleado con ese ID ya fue cargado previamente
	if((findEmployeeById(list,length,id))==1){
		printf("\nEL EMPLEADO CON EL ID %d YA FUE INGRESADO PREVIAMENTE\n",id);
	}else{
	    // caso contrario lo agrega
		int x = addEmployee(list,length,id,name,lastName,salary,sector);
		printf("\nEL EMPLEADO FUE AGREGADO A LA LISTA\n");
	}
}

void modificarEmpleado(Employee* list, int length){
    char name[51];
    char lastName[51];
    float salary;
    int sector;
    //pregunta si al menos hay 1 solo empleado
	if(existeEmpleado(list,length)==1){
        printf("\nINGRESE LOS DATOS DEL EMPLEADO\n");
        printf("\nINGRESE EL ID DEL EMPLEADO A MODIFICAR\n");
		int id;
		scanf("%d",&id);
		//verifico que el empleado con ese ID ingresado exista
		if((findEmployeeById(list,length,id))==1){


                int elimino = removeEmployee(list,1000,id);

				printf("\nINGRESE NOMBRE DEL EMPLEADO : ");
				scanf("%s",name);


				printf("\nINGRESE APELLIDO DEL EMPLEADO : ");
				scanf("%s",lastName);


				printf("\nINGRESE SUELDO DEL EMPLEADO : ");
				scanf("%f",&salary);


				printf("\nINGRESE NUMERO DEL SECTOR DEL EMPLEADO : ");
				scanf("%d",&sector);

			int v = addEmployee(list,length,id,name,lastName,salary,sector);
			if(v != -1){
				printf("\nEL EMPLEADO CON ID %d FUE MODIFICADO \n",id);
			}
		}else{
			printf("\nNO EXISTE EMPLEADO CON EL ID INGRESADO \n");
		}
	}else{
		printf("\nNO PUEDE REALIZAR ESTA OPERACION, YA QUE LA LISTA NO TIENE EMPLEADOS CARGADOS\n");
	}

}

void darBajaEmpleado(Employee* list, int length){
    // verifica que exista al menos un empleado para realizar la operacion
	if((existeEmpleado(list,length))==1){
		printf("\nINGRESE EL ID DEL EMPLEADO QUE QUIERE ELIMINAR : ");
		int id;
		scanf("%d",&id);
		// verifica si el empleado con ese ID esta en la lista
		if((findEmployeeById(list,length,id))==1){
			int r = removeEmployee(list,length,id);
			printf("\nEL EMPLEADO FUE DADO DE BAJA\n");
		}else{
            printf("\nNO EXISTE EMPLEADO CON EL ID INGRESADO \n");
		}
	}else{
        printf("\nNO PUEDE REALIZAR ESTA OPERACION, YA QUE LA LISTA NO TIENE EMPLEADOS CARGADOS\n");
	}



}

void informar(Employee* list, int length){
	if((existeEmpleado(list,length))==1){

		int opcion;
		/*
		1. Listado de los empleados ordenados alfab�ticamente por Apellido y Sector.
		2. Total y promedio de los salarios, y cu�ntos empleados superan el salario promedio.
		*/
		printf("\n\n*****************************************INFORMAR*************************************\n");
		printf("*(1)LISTADO DE EMPLEADOS POR APELLIDO Y SECTOR                                       *\n");
		printf("*(0)TOTAL Y PROMEDIO DE SALARIOS, Y CUANTOS EMPLEADOS SUPERAN EL SALARIO PROMEDIO    *\n");
		printf("**************************************************************************************\n\n");
		printf("INGRESE UNA OPCION : ");
		scanf("%d",&opcion);
		int opcionInf;
		switch(opcion){

			case 1:

				printf("\n\n*********************INFORMAR*****************\n");
				printf("*(1)INFORMAR DE FORMA ASCENDENTE             *\n");
				printf("*(0)INFORMAR DE FORMA DESCENDENTE            *\n");
				printf("**********************************************\n\n");
				printf("INGRESE UNA OPCION : ");
				scanf("%d",&opcionInf);
				//opcionInf me determina si me muestra los empleados en orden alfabetico creciente o decreciente
				sortEmployees(list,length,opcionInf);
				printEmployees(list,length);
				break;
			case 0:
				mostrarInformeSalario(list,length);
				break;

		}



	}else{
		printf("\nNO PUEDE MOSTRARSE INFORMACION PORQUE LA LISTA NO TIENE EMPLEADOS CARGADOS\n");
	}
}

