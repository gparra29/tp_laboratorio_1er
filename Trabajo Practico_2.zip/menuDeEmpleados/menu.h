#ifndef MENU
#define MENU
#include "ArraysEmployees.h"


void menu();
void ingresarEmpleado(Employee* list, int length);
void modificarEmpleado(Employee* list, int length);
void darBajaEmpleado(Employee* list, int length);
void informar(Employee* list, int length);


#endif // MENU
