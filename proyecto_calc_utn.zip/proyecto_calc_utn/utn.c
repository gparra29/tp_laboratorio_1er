#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include "utn.h"

void menu()
{

    int opcion; // ALMACENAR LA OPCION QUE EL USUARIO DIGITE


    printf("1.Calcular la suma (A+B)\n");
    printf("2.Calcular la restar (A-B)\n");
    printf("3.Calcular la multiplicacion (A*B)\n");
    printf("4.Calcular la division (A/B)\n");
    printf("5.Calcular el factorial (A!) y (B!)\n");
    printf("9.Salir\n");

    // ALMACENAMOS LA OPCION
    printf("\nDigite su opcion: ");
    fflush(stdin);
    scanf("%i", &opcion);


    do
    {
        // PEDIRLE LOS VALORES
        int numero_a, numero_b;
        if(opcion ==1 || opcion ==2 || opcion ==3 || opcion==4 || opcion==5)
        {

            printf("\nDigite valor para numero A: ");
            fflush(stdin);
            scanf("%i", &numero_a);


            printf("\nDigite valor para numero B: ");
            fflush(stdin);
            scanf("%i", &numero_b);


        }

        //Seccion de opciones de la operacion
        switch (opcion)
        {
        case 1:
            sumar(numero_a,numero_b);
            break;
        case 2:
            restar(numero_a,numero_b);
            break;
        case 3:
            multiplicar(numero_a,numero_b);
            break;
        case 4:
            dividir(numero_a,numero_b);
            break;
        case 5:
            factorear(numero_a, numero_b);
            break;
        case 9:
            salir();
            break;
        default:
            printf("Opcion invalida, vuelva a elegir una opcion\n\n");
            menu();
        }
        //Vuelve a desplegar el menu de opciones
        printf("Menu de opciones:\n");
        printf("\n1.Calcular la suma (A+B)\n");
        printf("2.Calcular la restar (A-B)\n");
        printf("3.Calcular la multiplicacion (A*B)\n");
        printf("4.Calcular la division (A/B)\n");
        printf("5.Calcular el factorial (A!) y (B!)\n");
        printf("9.Salir\n");

        // ALMACENAMOS LA OPCION
        printf("\nDigite su opcion: ");
        fflush(stdin);
        scanf("%i", &opcion);

    }
    while((opcion == 1) || (opcion == 2)||(opcion == 3)||(opcion == 4)||(opcion == 5) ); //Continuar

}//Fin del Menu
//Funcion para calcular la suma
void sumar(int numero_a, int numero_b)
{

    printf("El resultado de la suma es: %i ", numero_a + numero_b);
    printf("\n----------------------------------------------\n");

}
//Funcion para calcular la resta
void restar(int numero_a, int numero_b)
{

    printf("El resultado de la resta es: %i ", numero_a - numero_b);
    printf("\n----------------------------------------------\n");

}

//Funcion para calcular la multiplicacion
void multiplicar(int numero_a, int numero_b)
{

    printf("El resultado de la multiplicacion es: %i ", numero_a * numero_b);
    printf("\n----------------------------------------------\n");

}

//Funcion para calcular la division
void dividir(float numero_a, float numero_b)
{
    if (numero_b ==0)
    {

        printf("No se puede dividir por cero");
    }
    else
    {
        printf("El resultado de la division es: %f ", numero_a / numero_b);
        printf("\n----------------------------------------------\n");
    }

}
//Funcion para calcular el factorial
void factorear(int numero_a, int numero_b)
{
    printf("resultado del factorial A es %i y el resultado de su calculo B es %i\n",
           calcularFact(numero_a),
           calcularFact(numero_b));
    printf("\n----------------------------------------------\n");
}

//Operacion mediante un contador usando for, para calcular el factorial
int calcularFact(int numero)
{
    int factorial = 1;
    for (int i = 0; i < numero; i++)
    {
        factorial = factorial * (i + 1);
    }
    return factorial;
}
//Mensaje al salir de la calculadora
void salir()
{
    printf("Salio de la calculadora");
    exit(0);

}
