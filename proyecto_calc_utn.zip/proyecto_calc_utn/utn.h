#ifndef UTN_H_INCLUDED
#define UTN_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
// PROTOTIPOS / FIRMAS

void menu();
void sumar(int numero_a, int numero_b);
void restar(int numero_a, int numero_b);
void multiplicar(int numero_a, int numero_b);
void dividir(float numero_a, float numero_b);
void factorear(int numero_a, int numero_b);
int calcularFact(int numero);
void salir();

#endif // UTN_H_INCLUDED
