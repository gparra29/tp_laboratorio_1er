/*
 ============================================================================
 Name        : proyectocalculadora.c
 Author      : Rolando Guido, Parra
 Version     :
 Copyright   : Your copyright notice
 Description : Calculadora in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include "utn.h"



int main()
{
    printf("\nMenu de opciones:\n");
    printf("\nDigite la operacion que desea calcular\n");

    menu(); // LLAMAMOS A LA FUNCION

    printf("-----FIN DE OPERACION-------");

    return 0;
}
